<?php

/* -------------------------------------------------------
 *
 *   LiveStreet (1.x)
 *   Plugin Disabling personal blogs (v.1.2)
 *   Copyright © 2011 Bishovec Nikolay
 *
 * --------------------------------------------------------
 *
 *   Plugin Page: http://netlanc.net
 *   Contact e-mail: netlanc@yandex.ru
 *
  ---------------------------------------------------------
 */
return array(
    'topic_create_blog_personal' => 'Выберите блог для публикации',
    'topic_create_blog_id_empty' => 'Выберите блог в который хотите сделать публикацию'
);
?>
