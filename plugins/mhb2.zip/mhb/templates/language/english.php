<?php
/*
 * 
 * Project Name : Must Have Blogs
 * Copyright (C) 2011 Alexei Lukin. All rights reserved.
 * License: GNU GPL v2, http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 *
 */


return array(
'admin_admin_menu'=>'Autojoin blogs',
'mhb_info_header'=>'Project information',
'mhb_info_pluginname'=>'Must Have Blogs',
'mhb_info_version'=>MHB_VERSION,
'mhb_info_author'=>'Alexei Lukin aka Kerby',
'mhb_info_email'=>'kerbylav@gmail.com',
'mhb_info_url'=>'http://imthinker.ru/plugin-mhb',

'mhb_donate'=>'This plugin is free, but author will thankfully accept any donation made to WebMoney purse  Z334942299641 or R328441042941, or Money.Yandex 41001830047811, yet better , а лучше - <a href="http://livestreetcms.com/profile/kerby/donate/" target="_blank">here</a>. And remember, even couple of bucks could make an evening with beer :)',

'mhb_blog_title'=>'Blog title',
'mhb_auto_join_title'=>'Autojoin',
'mhb_cant_leave_title'=>'Can\'t leave',

'mhb_submit'=>'Save',

'mhb_note'=>'Asterisk [*] marks a closed blog<br/><br/>',
);

?>