<?php
/*
 *
 * Project Name : Must Have Blogs
 * Copyright (C) 2011-2012 Alexei Lukin. All rights reserved.
 * License: GNU GPL v2, http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 *
 */


return array(
'admin_admin_menu'=>'Блоги для автоматического вступления',

'mhb_info_header'=>'Информация о проекте',
'mhb_info_pluginname'=>'Must Have Blogs',
'mhb_info_version'=>MHB_VERSION,
'mhb_info_author'=>'Alexei Lukin aka Kerby',
'mhb_info_email'=>'kerbylav@gmail.com',
'mhb_info_url'=>'http://imthinker.ru/plugin-mhb',

'mhb_donate'=>'Этот плагин бесплатный, но автор с благодарностью примет материальное вознаграждение на кошельки WebMoney Z334942299641 и R328441042941, а так же Яндекс.Деньги счет 41001830047811, а лучше - <a href="http://livestreetcms.ru/profile/kerby/donate/" target="_blank">сюда</a>. Помните, даже пара баксов могут скрасить вечер пивом :)',

'mhb_blog_title'=>'Название блога',
'mhb_auto_join_title'=>'Автоприсоединение',
'mhb_cant_leave_title'=>'Нельзя покинуть',

'mhb_cant_leave_blog'=>'Администрация запретила покидать этот блог',

'mhb_submit'=>'Сохранить',

'mhb_note'=>'Звездочкой [*] отмечены закрытые блоги<br/><br/>',
);

?>
